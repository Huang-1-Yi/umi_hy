# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.

import ctypes
import os
import time


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    CUR_PATH=os.path.dirname(os.path.realpath(__file__))
    dllPath=os.path.join(CUR_PATH,"libRM_Base.so")
    pDll=ctypes.cdll.LoadLibrary(dllPath)

    pDll.RM_API_Init(65,0)

#   连接机械臂
    byteIP = bytes("192.168.1.18","gbk")
    nSocket = pDll.Arm_Socket_Start(byteIP, 8080, 200)
    print (nSocket)

#   查询机械臂连接状态
    nRet = pDll.Arm_Socket_State(nSocket)
    print(nRet)

#   设置机械臂末端参数为初始值
    nRet = pDll.Set_Arm_Tip_Init(nSocket, 1)
    print(nRet)

#   设置机械臂动力学碰撞检测等级
    nRet = pDll.Set_Collision_Stage(nSocket, 0, 1)
    print(nRet)

#   机械臂Move_J运动
    #   初始位置
    float_joint = ctypes.c_float*6
    joint1 = float_joint()
    joint1[0] = 0
    joint1[1] = 0
    joint1[2] = 0
    joint1[3] = 0
    joint1[4] = 0
    joint1[5] = 0
    pDll.Movej_Cmd.argtypes = (ctypes.c_int, ctypes.c_float * 6, ctypes.c_byte, ctypes.c_float, ctypes.c_bool)
    pDll.Movej_Cmd.restype = ctypes.c_int
    ret = pDll.Movej_Cmd(nSocket, joint1, 20, 0, 1)

    i = 1
    while i < 3:
        time.sleep(1)
        i += 1

#   关闭连接
    pDll.Arm_Socket_Close(nSocket)

# See PyCharm help at https://www.jetbrains.com/help/pycharm/

